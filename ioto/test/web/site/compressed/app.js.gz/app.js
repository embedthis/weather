console.log('Hello World from compressed test');
